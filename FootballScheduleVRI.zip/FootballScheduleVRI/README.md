# FootballClubVRI
Dicoding Course Project ( Accessing data from API ) , Kotlin Android Developer Expert 2018
